﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ekz_bulat
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "ekz_bulDataSet.rase". При необходимости она может быть перемещена или удалена.
            this.raseTableAdapter.Fill(this.ekz_bulDataSet.rase);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "ekz_bulDataSet.tikets". При необходимости она может быть перемещена или удалена.
            this.tiketsTableAdapter.Fill(this.ekz_bulDataSet.tikets);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "ekz_bulDataSet.airplane". При необходимости она может быть перемещена или удалена.
            this.airplaneTableAdapter.Fill(this.ekz_bulDataSet.airplane);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "ekz_bulDataSet.sum". При необходимости она может быть перемещена или удалена.
            // this.sumTableAdapter.Fill(this.ekz_bulDataSet.sum);

        }

        private void sumDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.sumTableAdapter.Fill(this.ekz_bulDataSet.sum);
        }

        private void airplaneDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tiketsDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void raseDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
