﻿namespace ekz_bulat
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ekz_bulDataSet = new ekz_bulat.ekz_bulDataSet();
            this.sumBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sumTableAdapter = new ekz_bulat.ekz_bulDataSetTableAdapters.sumTableAdapter();
            this.tableAdapterManager = new ekz_bulat.ekz_bulDataSetTableAdapters.TableAdapterManager();
            this.sumBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.sumBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.button1 = new System.Windows.Forms.Button();
            this.airplaneBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.airplaneTableAdapter = new ekz_bulat.ekz_bulDataSetTableAdapters.airplaneTableAdapter();
            this.airplaneDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tiketsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tiketsTableAdapter = new ekz_bulat.ekz_bulDataSetTableAdapters.tiketsTableAdapter();
            this.tiketsDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sumDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.raseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.raseTableAdapter = new ekz_bulat.ekz_bulDataSetTableAdapters.raseTableAdapter();
            this.raseDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.ekz_bulDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumBindingNavigator)).BeginInit();
            this.sumBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.airplaneBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.airplaneDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tiketsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tiketsDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.raseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.raseDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // ekz_bulDataSet
            // 
            this.ekz_bulDataSet.DataSetName = "ekz_bulDataSet";
            this.ekz_bulDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sumBindingSource
            // 
            this.sumBindingSource.DataMember = "sum";
            this.sumBindingSource.DataSource = this.ekz_bulDataSet;
            // 
            // sumTableAdapter
            // 
            this.sumTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.airplaneTableAdapter = this.airplaneTableAdapter;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.raseTableAdapter = this.raseTableAdapter;
            this.tableAdapterManager.tiketsTableAdapter = this.tiketsTableAdapter;
            this.tableAdapterManager.UpdateOrder = ekz_bulat.ekz_bulDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // sumBindingNavigator
            // 
            this.sumBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.sumBindingNavigator.BindingSource = this.sumBindingSource;
            this.sumBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.sumBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.sumBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.sumBindingNavigatorSaveItem});
            this.sumBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.sumBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.sumBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.sumBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.sumBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.sumBindingNavigator.Name = "sumBindingNavigator";
            this.sumBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.sumBindingNavigator.Size = new System.Drawing.Size(813, 25);
            this.sumBindingNavigator.TabIndex = 0;
            this.sumBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 15);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // sumBindingNavigatorSaveItem
            // 
            this.sumBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.sumBindingNavigatorSaveItem.Enabled = false;
            this.sumBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("sumBindingNavigatorSaveItem.Image")));
            this.sumBindingNavigatorSaveItem.Name = "sumBindingNavigatorSaveItem";
            this.sumBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 20);
            this.sumBindingNavigatorSaveItem.Text = "Сохранить данные";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(532, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(163, 68);
            this.button1.TabIndex = 2;
            this.button1.Text = "Вычислить общую сумму продаж рейсов по  рейтингу популярности";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // airplaneBindingSource
            // 
            this.airplaneBindingSource.DataMember = "airplane";
            this.airplaneBindingSource.DataSource = this.ekz_bulDataSet;
            // 
            // airplaneTableAdapter
            // 
            this.airplaneTableAdapter.ClearBeforeFill = true;
            // 
            // airplaneDataGridView
            // 
            this.airplaneDataGridView.AutoGenerateColumns = false;
            this.airplaneDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.airplaneDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.airplaneDataGridView.DataSource = this.airplaneBindingSource;
            this.airplaneDataGridView.Location = new System.Drawing.Point(12, 28);
            this.airplaneDataGridView.Name = "airplaneDataGridView";
            this.airplaneDataGridView.Size = new System.Drawing.Size(197, 155);
            this.airplaneDataGridView.TabIndex = 3;
            this.airplaneDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.airplaneDataGridView_CellContentClick);
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "ID";
            this.dataGridViewTextBoxColumn3.HeaderText = "ID";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "name";
            this.dataGridViewTextBoxColumn4.HeaderText = "name";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "tipe";
            this.dataGridViewTextBoxColumn5.HeaderText = "tipe";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "kolvo_pass";
            this.dataGridViewTextBoxColumn6.HeaderText = "kolvo_pass";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // tiketsBindingSource
            // 
            this.tiketsBindingSource.DataMember = "tikets";
            this.tiketsBindingSource.DataSource = this.ekz_bulDataSet;
            // 
            // tiketsTableAdapter
            // 
            this.tiketsTableAdapter.ClearBeforeFill = true;
            // 
            // tiketsDataGridView
            // 
            this.tiketsDataGridView.AutoGenerateColumns = false;
            this.tiketsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tiketsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11});
            this.tiketsDataGridView.DataSource = this.tiketsBindingSource;
            this.tiketsDataGridView.Location = new System.Drawing.Point(12, 364);
            this.tiketsDataGridView.Name = "tiketsDataGridView";
            this.tiketsDataGridView.Size = new System.Drawing.Size(197, 168);
            this.tiketsDataGridView.TabIndex = 5;
            this.tiketsDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.tiketsDataGridView_CellContentClick);
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn9.HeaderText = "id";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "rase";
            this.dataGridViewTextBoxColumn10.HeaderText = "rase";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "kolvo_sell";
            this.dataGridViewTextBoxColumn11.HeaderText = "kolvo_sell";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // sumDataGridView
            // 
            this.sumDataGridView.AutoGenerateColumns = false;
            this.sumDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sumDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.sumDataGridView.DataSource = this.sumBindingSource;
            this.sumDataGridView.Location = new System.Drawing.Point(491, 113);
            this.sumDataGridView.Name = "sumDataGridView";
            this.sumDataGridView.Size = new System.Drawing.Size(241, 419);
            this.sumDataGridView.TabIndex = 5;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "price";
            this.dataGridViewTextBoxColumn1.HeaderText = "price";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "rase";
            this.dataGridViewTextBoxColumn2.HeaderText = "rase";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // raseBindingSource
            // 
            this.raseBindingSource.DataMember = "rase";
            this.raseBindingSource.DataSource = this.ekz_bulDataSet;
            // 
            // raseTableAdapter
            // 
            this.raseTableAdapter.ClearBeforeFill = true;
            // 
            // raseDataGridView
            // 
            this.raseDataGridView.AutoGenerateColumns = false;
            this.raseDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.raseDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14});
            this.raseDataGridView.DataSource = this.raseBindingSource;
            this.raseDataGridView.Location = new System.Drawing.Point(12, 189);
            this.raseDataGridView.Name = "raseDataGridView";
            this.raseDataGridView.Size = new System.Drawing.Size(197, 158);
            this.raseDataGridView.TabIndex = 5;
            this.raseDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.raseDataGridView_CellContentClick);
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "ID";
            this.dataGridViewTextBoxColumn7.HeaderText = "ID";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "airplane";
            this.dataGridViewTextBoxColumn8.HeaderText = "airplane";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "punct_naz";
            this.dataGridViewTextBoxColumn12.HeaderText = "punct_naz";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "cost";
            this.dataGridViewTextBoxColumn13.HeaderText = "cost";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "date";
            this.dataGridViewTextBoxColumn14.HeaderText = "date";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(813, 552);
            this.Controls.Add(this.raseDataGridView);
            this.Controls.Add(this.sumDataGridView);
            this.Controls.Add(this.tiketsDataGridView);
            this.Controls.Add(this.airplaneDataGridView);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.sumBindingNavigator);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ekz_bulDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumBindingNavigator)).EndInit();
            this.sumBindingNavigator.ResumeLayout(false);
            this.sumBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.airplaneBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.airplaneDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tiketsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tiketsDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sumDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.raseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.raseDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ekz_bulDataSet ekz_bulDataSet;
        private System.Windows.Forms.BindingSource sumBindingSource;
        private ekz_bulDataSetTableAdapters.sumTableAdapter sumTableAdapter;
        private ekz_bulDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator sumBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton sumBindingNavigatorSaveItem;
        private System.Windows.Forms.Button button1;
        private ekz_bulDataSetTableAdapters.airplaneTableAdapter airplaneTableAdapter;
        private System.Windows.Forms.BindingSource airplaneBindingSource;
        private ekz_bulDataSetTableAdapters.tiketsTableAdapter tiketsTableAdapter;
        private System.Windows.Forms.DataGridView airplaneDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.BindingSource tiketsBindingSource;
        private System.Windows.Forms.DataGridView tiketsDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridView sumDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private ekz_bulDataSetTableAdapters.raseTableAdapter raseTableAdapter;
        private System.Windows.Forms.BindingSource raseBindingSource;
        private System.Windows.Forms.DataGridView raseDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
    }
}

